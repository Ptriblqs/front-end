import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:inta301/shared/shared.dart';
import '../../services/dokumen_service.dart';
import 'package:file_picker/file_picker.dart';

class UbahStatusMenungguModal extends StatefulWidget {
  final int dokumenId;
  final String judulDokumen;
  final Function(String, String?) onSave;

  const UbahStatusMenungguModal({
    super.key,
    required this.dokumenId,
    required this.judulDokumen,
    required this.onSave,
  });

  @override
  State<UbahStatusMenungguModal> createState() =>
      _UbahStatusMenungguModalState();
}

class _UbahStatusMenungguModalState extends State<UbahStatusMenungguModal> {
  String selectedStatus = "Menunggu";
  final TextEditingController catatanController = TextEditingController();
  bool isLoading = false;
  PlatformFile? pickedFile;

  Future<void> saveStatus() async {
    // Validasi: jika status Revisi, catatan harus diisi
    if (selectedStatus == "Revisi" && catatanController.text.trim().isEmpty) {
      Get.snackbar(
        "Error",
        "Catatan revisi harus diisi",
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.TOP,
      );
      return;
    }

    setState(() => isLoading = true);

    try {
      final response = await DokumenService.updateStatusDokumen(
        dokumenId: widget.dokumenId,
        status: selectedStatus,
        catatanRevisi: selectedStatus == "Revisi" ? catatanController.text : null,
      );

      setState(() => isLoading = false);

      if (response['success'] == true) {
        widget.onSave(selectedStatus, selectedStatus == 'Revisi' ? catatanController.text : null);
        Get.back();

        if (pickedFile != null) {
          Get.snackbar(
            'Informasi',
            'File revisi terpilih tetapi pengunggahan file dari dosen mungkin tidak didukung. Jika perlu, minta mahasiswa mengunggah revisi.',
            snackPosition: SnackPosition.TOP,
            backgroundColor: Colors.white,
            titleText: const Text('Perhatian', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
            messageText: Text('File: ${pickedFile!.name}', style: const TextStyle(color: Colors.black)),
          );
        } else {
          Get.snackbar(
            '',
            '',
            backgroundColor: Colors.white,
            snackPosition: SnackPosition.TOP,
            margin: const EdgeInsets.all(16),
            titleText: const Text(
              "Berhasil",
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            messageText: Text(
              "Status dokumen berhasil diubah menjadi $selectedStatus",
              style: const TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          );
        }
      }
    } catch (e) {
      setState(() => isLoading = false);
      Get.snackbar(
        "Gagal",
        "Gagal mengubah status: $e",
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.TOP,
      );
    }
  }

  Future<void> pickFile() async {
    try {
      final res = await FilePicker.platform.pickFiles(withData: true);
      if (res != null && res.files.isNotEmpty) {
        setState(() {
          pickedFile = res.files.first;
        });
      }
    } catch (e) {
      Get.snackbar('Gagal', 'Gagal memilih file: $e', snackPosition: SnackPosition.TOP);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // header
            Container(
              height: 6,
              width: 60,
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(4)),
            ),

            const Text(
              'Ubah Status',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(widget.judulDokumen, style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 18),

            // dropdown style selection
            Align(
              alignment: Alignment.centerLeft,
              child: const Text('Pilih Status', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFFE8F3FF),
                borderRadius: BorderRadius.circular(12),
              ),
              child: DropdownButtonFormField<String>(
                value: selectedStatus,
                items: const [
                  DropdownMenuItem(value: 'Menunggu', child: Text('Menunggu')),
                  DropdownMenuItem(value: 'Revisi', child: Text('Revisi')),
                  DropdownMenuItem(value: 'Disetujui', child: Text('Disetujui')),
                ],
                onChanged: (v) => setState(() => selectedStatus = v ?? 'Menunggu'),
                decoration: const InputDecoration(border: InputBorder.none),
              ),
            ),

            const SizedBox(height: 16),

            // Catatan Revisi
            if (selectedStatus == 'Revisi') ...[
              Align(alignment: Alignment.centerLeft, child: const Text('Catatan Dosen', style: TextStyle(fontWeight: FontWeight.bold))),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: const Color(0xFFE8F3FF), borderRadius: BorderRadius.circular(12)),
                child: TextField(
                  controller: catatanController,
                  maxLines: 4,
                  decoration: const InputDecoration(border: InputBorder.none, hintText: 'Tulis catatan revisi di sini...'),
                ),
              ),
              const SizedBox(height: 12),

              // File revisi picker (UI only)
              Align(alignment: Alignment.centerLeft, child: const Text('File Revisi', style: TextStyle(fontWeight: FontWeight.bold))),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: Container(
                      height: 38,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(8)),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              pickedFile?.name ?? 'Belum ada file terpilih',
                              style: const TextStyle(fontSize: 13),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton(
                    onPressed: pickFile,
                    style: ElevatedButton.styleFrom(backgroundColor: primaryColor, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
                    child: const Text('Pilih File'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
            ],

            const SizedBox(height: 6),

            // Save button
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: isLoading ? null : saveStatus,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.blueGrey[800], shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                child: isLoading ? const CircularProgressIndicator(color: Colors.white) : const Text('SIMPAN', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    catatanController.dispose();
    super.dispose();
  }
}