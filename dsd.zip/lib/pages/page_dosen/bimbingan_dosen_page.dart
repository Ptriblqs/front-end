import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:inta301/controllers/daftar_mahasiswa_controller.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:inta301/shared/shared.dart';
import 'package:inta301/routes/app_pages.dart';
import 'package:inta301/controllers/menu_dosen_controller.dart';
import 'package:inta301/services/ajukan_pembimbing_service.dart';
import 'package:intl/intl.dart';
import 'package:inta301/services/bimbingan_service.dart';
import 'package:inta301/models/mahasiswa_bimbingan_model.dart';

// Import widget card & page
import 'package:inta301/pages/page_dosen/mahasiswa_card.dart';
import 'package:inta301/pages/page_dosen/bimbingan_card.dart';
import 'package:inta301/pages/page_dosen/form_ajuan_bimbingan_page.dart';
import 'package:inta301/pages/page_dosen/form_ajuan_dospem.dart';

/// ======================== BIMBINGAN DOSEN PAGE ========================
class BimbinganDosenPage extends GetView<MenuDosenController> {
  const BimbinganDosenPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Set halaman controller
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.setPage(PageTypeDosen.bimbingan);
    });

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        centerTitle: true,
        elevation: 0,
        title: const Text(
          "Bimbingan Mahasiswa",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20,
            fontFamily: 'Poppins',
          ),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [primaryColor, dangerColor],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: DefaultTabController(
        length: 3,
        child: Column(
          children: [
            _buildTabBar(),
            Expanded(
              child: TabBarView(
                children: [
                  _DaftarMahasiswaTab(),
                  _DaftarBimbinganTab(),
                  const DaftarAjuanDosenTab(),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Obx(
        () => _BottomNavDosen(currentPage: controller.currentPage.value),
      ),
    );
  }

  /// Tab Bar Widget
  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: defaultMargin, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: TabBar(
        indicator: BoxDecoration(
          color: primaryColor,
          borderRadius: BorderRadius.circular(15),
        ),
        labelColor: Colors.white,
        unselectedLabelColor: Colors.black,
        indicatorSize: TabBarIndicatorSize.tab,
        labelStyle: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 13,
          fontFamily: 'Poppins',
        ),
        tabs: const [
          Tab(child: _TabLabel(title: "Mahasiswa")),
          Tab(child: _TabLabel(title: "Bimbingan")),
          Tab(child: _TabLabel(title: "Ajuan")),
        ],
      ),
    );
  }
}

/// Tab Label Widget
class _TabLabel extends StatelessWidget {
  final String title;
  const _TabLabel({required this.title});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text("Daftar", style: TextStyle(fontSize: 12)),
        const SizedBox(height: 2),
        Text(
          title,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}

/// ======================== DAFTAR MAHASISWA ========================
class _DaftarMahasiswaTab extends StatelessWidget {
  // Inisialisasi controller GetX
  final controller = Get.put(DaftarMahasiswaController());

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      // Loading indicator
      if (controller.isLoading.value) {
        return const Center(
          child: CircularProgressIndicator(color: primaryColor),
        );
      }

      // Jika daftar mahasiswa kosong
      if (controller.mahasiswaList.isEmpty) {
        return Center(
          child: Text(
            controller.errorMessage.value.isEmpty
                ? "Belum ada mahasiswa"
                : controller.errorMessage.value,
            style: const TextStyle(
              fontFamily: 'Poppins',
              color: Colors.grey,
            ),
          ),
        );
      }

      // List mahasiswa
      return ListView.builder(
        padding: const EdgeInsets.all(defaultMargin),
        itemCount: controller.mahasiswaList.length,
        itemBuilder: (context, index) {
          final mhs = controller.mahasiswaList[index];

          // Pastikan properti model tidak null
          final nama = mhs.namaMahasiswa;
          final nim = mhs.nim;
          final prodi = mhs.programStudi;

          return MahasiswaCard(
            nama: nama,
            nim: nim,
            prodi: prodi,
            onAjukanBimbingan: () => _showAjukanDialog(context, mhs),
          );
        },
      );
    });
  }

  void _showAjukanDialog(BuildContext context, MahasiswaBimbinganModel mhs) {
    final TextEditingController _judulController = TextEditingController();
    final TextEditingController _tanggalController = TextEditingController();
    final TextEditingController _waktuController = TextEditingController();
    final TextEditingController _lokasiController = TextEditingController();
    final TextEditingController _catatanController = TextEditingController();

    String _selectedJenisBimbingan = 'offline';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (modalContext) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setModalState) {
            return DraggableScrollableSheet(
              expand: false,
              initialChildSize: 0.75,
              minChildSize: 0.4,
              maxChildSize: 0.95,
              builder: (context, scrollController) {
                return Container(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
                  ),
                  child: SingleChildScrollView(
                    controller: scrollController,
                    padding: EdgeInsets.only(
                      left: 20,
                      right: 20,
                      top: 20,
                      bottom: MediaQuery.of(context).viewInsets.bottom + 20,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Center(
                          child: Container(width: 60, height: 5, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
                        ),
                        const SizedBox(height: 16),
                        Center(
                          child: Text('Ajukan Jadwal Bimbingan untuk ${mhs.namaMahasiswa}', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                        ),
                        const SizedBox(height: 20),
                        const SizedBox(height: 8),
                        TextField(controller: _judulController, decoration: const InputDecoration(labelText: 'Judul Bimbingan')),
                        const SizedBox(height: 15),
                        GestureDetector(
                          onTap: () async {
                            FocusScope.of(modalContext).unfocus();
                            DateTime? pickedDate = await showDatePicker(
                              context: modalContext,
                              initialDate: DateTime.now(),
                              firstDate: DateTime.now(),
                              lastDate: DateTime.now().add(const Duration(days: 365)),
                              locale: const Locale('id', 'ID'),
                            );
                            if (pickedDate != null) {
                              setModalState(() {
                                _tanggalController.text = DateFormat('EEEE, dd MMMM yyyy', 'id_ID').format(pickedDate);
                              });
                            }
                          },
                          child: AbsorbPointer(
                            child: TextField(
                              controller: _tanggalController,
                              decoration: InputDecoration(suffixIcon: Icon(Icons.calendar_today_outlined, color: primaryColor), hintText: 'Pilih tanggal bimbingan'),
                            ),
                          ),
                        ),
                        const SizedBox(height: 15),
                        TextField(
                          controller: _waktuController,
                          keyboardType: TextInputType.datetime,
                          decoration: InputDecoration(
                            labelText: 'Waktu (contoh: 10:30)',
                            suffixIcon: IconButton(
                              icon: Icon(Icons.access_time, color: primaryColor),
                              onPressed: () async {
                                FocusScope.of(modalContext).unfocus();
                                final t = await showTimePicker(context: modalContext, initialTime: TimeOfDay.now());
                                if (t != null) setModalState(() => _waktuController.text = t.format(modalContext));
                              },
                            ),
                          ),
                        ),
                        const SizedBox(height: 15),
                        Row(
                          children: [
                            Expanded(
                              child: RadioListTile<String>(
                                title: const Text('Offline'),
                                value: 'offline',
                                groupValue: _selectedJenisBimbingan,
                                onChanged: (v) => setModalState(() => _selectedJenisBimbingan = v!),
                                activeColor: primaryColor,
                                contentPadding: EdgeInsets.zero,
                              ),
                            ),
                            Expanded(
                              child: RadioListTile<String>(
                                title: const Text('Online'),
                                value: 'online',
                                groupValue: _selectedJenisBimbingan,
                                onChanged: (v) => setModalState(() => _selectedJenisBimbingan = v!),
                                activeColor: primaryColor,
                                contentPadding: EdgeInsets.zero,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 15),
                        TextField(controller: _lokasiController, decoration: InputDecoration(hintText: _selectedJenisBimbingan == 'online' ? 'Link Zoom/Google Meet' : 'Contoh: Ruang B-203')),
                        const SizedBox(height: 15),
                        TextField(controller: _catatanController, maxLines: 3, decoration: const InputDecoration(hintText: 'Catatan tambahan')),
                        const SizedBox(height: 25),
                        SizedBox(
                          width: double.infinity,
                          height: 55,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(backgroundColor: dangerColor, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                            onPressed: () async {
                              // Validation
                              if (_judulController.text.trim().isEmpty) {
                                Get.snackbar('Error', 'Judul bimbingan harus diisi', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red, colorText: Colors.white);
                                return;
                              }
                              if (_tanggalController.text.isEmpty) {
                                Get.snackbar('Error', 'Tanggal harus dipilih', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red, colorText: Colors.white);
                                return;
                              }
                              if (_waktuController.text.trim().isEmpty) {
                                Get.snackbar('Error', 'Waktu harus diisi', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red, colorText: Colors.white);
                                return;
                              }
                              if (_lokasiController.text.trim().isEmpty) {
                                Get.snackbar('Error', 'Lokasi harus diisi', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red, colorText: Colors.white);
                                return;
                              }

                              try {
                                final DateFormat inputFormat = DateFormat('EEEE, dd MMMM yyyy', 'id_ID');
                                final DateTime parsedDate = inputFormat.parse(_tanggalController.text);
                                final String formattedDate = DateFormat('yyyy-MM-dd').format(parsedDate);

                                final timeRegex = RegExp(r'^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$');
                                if (!timeRegex.hasMatch(_waktuController.text.trim())) {
                                  Get.snackbar('Error', 'Format waktu harus HH:mm (contoh: 10:30)', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red, colorText: Colors.white);
                                  return;
                                }

                                final prefs = await SharedPreferences.getInstance();
                                final token = prefs.getString('token');
                                if (token == null) throw 'Token tidak ditemukan';

                                final result = await AjukanPembimbingService.createJadwalBimbingan(
                                  mahasiswaId: mhs.mahasiswaId,
                                  judulBimbingan: _judulController.text.trim(),
                                  tanggal: formattedDate,
                                  waktu: _waktuController.text.trim(),
                                  lokasi: _lokasiController.text.trim(),
                                  token: token,
                                );

                                if (result['success'] == true) {
                                  Navigator.pop(modalContext);
                                  Get.snackbar('Berhasil', result['message'] ?? 'Jadwal bimbingan berhasil diajukan', snackPosition: SnackPosition.TOP, backgroundColor: Colors.white, colorText: Colors.black);
                                } else {
                                  Get.snackbar('Error', result['message'] ?? 'Gagal mengajukan jadwal', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red, colorText: Colors.white);
                                }
                              } catch (e) {
                                Get.snackbar('Error', 'Gagal mengajukan jadwal: $e', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red, colorText: Colors.white);
                              }
                            },
                            child: const Text('Ajukan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white)),
                          ),
                        ),
                        const SizedBox(height: 12),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}

/// ======================== DAFTAR BIMBINGAN ========================
class _DaftarBimbinganTab extends StatefulWidget {
  @override
  State<_DaftarBimbinganTab> createState() => _DaftarBimbinganTabState();
}

class _DaftarBimbinganTabState extends State<_DaftarBimbinganTab> {
  final BimbinganService _service = BimbinganService();
  List<Map<String, dynamic>> _bimbinganList = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadBimbingan();
  }

  Future<void> _loadBimbingan() async {
    setState(() => _loading = true);
    final result = await _service.getBimbinganDosen();
    if (result['success'] == true) {
      dynamic raw = result['data'] ?? [];
      List list = [];
      if (raw is List) list = raw;
      else if (raw is Map && raw['bimbingan'] is List) list = raw['bimbingan'];

      setState(() {
        _bimbinganList = List<Map<String, dynamic>>.from(list);
        _loading = false;
      });
    } else {
      setState(() => _loading = false);
      Get.snackbar('Error', result['message'] ?? 'Gagal memuat bimbingan', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red, colorText: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: primaryColor));

    if (_bimbinganList.isEmpty) {
      return const Center(
        child: Text(
          "Belum ada bimbingan",
          style: TextStyle(fontFamily: 'Poppins', color: Colors.grey),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadBimbingan,
      color: primaryColor,
      child: ListView.builder(
        padding: const EdgeInsets.all(defaultMargin),
        itemCount: _bimbinganList.length,
        itemBuilder: (context, index) {
          final bimbingan = _bimbinganList[index];
          return BimbinganCard(
            nama: bimbingan['nama_mahasiswa'] ?? bimbingan['nama'] ?? '-',
            nim: bimbingan['nim'] ?? '-',
            prodi: bimbingan['program_studi'] ?? bimbingan['prodi'] ?? '-',
            onTap: () => Get.to(() => const FormAjuanBimbinganPage()),
          );
        },
      ),
    );
  }
}

/// ======================== DAFTAR AJUAN DOSEN ========================
class DaftarAjuanDosenTab extends StatefulWidget {
  const DaftarAjuanDosenTab({super.key});

  @override
  State<DaftarAjuanDosenTab> createState() => _DaftarAjuanDosenTabState();
}

class _DaftarAjuanDosenTabState extends State<DaftarAjuanDosenTab> {
  List<Map<String, dynamic>> ajuanList = [];
  bool isLoading = true;
  String filterStatus = 'semua'; // semua, menunggu, diterima, ditolak
  // Track processing ajuan ids to prevent duplicate actions
  final Set<int> _processingIds = {};

  @override
  void initState() {
    super.initState();
    _loadAjuan();
  }

  Future<void> _loadAjuan() async {
    setState(() => isLoading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token');

      if (token == null) {
        setState(() => isLoading = false);
        Get.snackbar(
          'Error',
          'Token tidak ditemukan. Silakan login ulang.',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red,
          colorText: Colors.white,
          margin: const EdgeInsets.all(16),
        );
        return;
      }

      final result = await AjukanPembimbingService.getAjuanMasukDosen(token: token);

      if (result['success'] == true) {
        setState(() {
          ajuanList = List<Map<String, dynamic>>.from(result['data'] ?? []);
          isLoading = false;
        });
      } else {
        setState(() => isLoading = false);
        Get.snackbar(
          'Error',
          result['message'] ?? 'Gagal memuat data',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red,
          colorText: Colors.white,
          margin: const EdgeInsets.all(16),
        );
      }
    } catch (e) {
      setState(() => isLoading = false);
      Get.snackbar(
        'Error',
        'Terjadi kesalahan: $e',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
        margin: const EdgeInsets.all(16),
      );
    }
  }

  List<Map<String, dynamic>> get filteredAjuan {
    if (filterStatus == 'semua') return ajuanList;
    return ajuanList.where((ajuan) => ajuan['status'] == filterStatus).toList();
  }

  int get menungguCount => ajuanList.where((a) => a['status'] == 'menunggu').length;
  int get diterimaCount => ajuanList.where((a) => a['status'] == 'diterima').length;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildFilterChips(),
        Expanded(child: _buildAjuanList()),
      ],
    );
  }

  Widget _buildFilterChips() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: Colors.grey.withOpacity(0.2), blurRadius: 5, offset: const Offset(0, 2))],
      ),
      child: Row(
        children: [
          Expanded(child: _buildFilterChip('Semua', 'semua', ajuanList.length)),
          const SizedBox(width: 8),
          Expanded(child: _buildFilterChip('Menunggu', 'menunggu', menungguCount)),
          const SizedBox(width: 8),
          Expanded(child: _buildFilterChip('Diterima', 'diterima', diterimaCount)),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String label, String value, int count) {
    final isSelected = filterStatus == value;
    return GestureDetector(
      onTap: () => setState(() => filterStatus = value),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
        decoration: BoxDecoration(
          color: isSelected ? primaryColor : Colors.grey[200],
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Flexible(
              child: Text(
                label,
                style: TextStyle(color: isSelected ? Colors.white : Colors.black87, fontWeight: FontWeight.bold, fontSize: 13),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(width: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: isSelected ? Colors.white : primaryColor,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                count.toString(),
                style: TextStyle(color: isSelected ? primaryColor : Colors.white, fontWeight: FontWeight.bold, fontSize: 11),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAjuanList() {
    if (isLoading) return const Center(child: CircularProgressIndicator(color: primaryColor));

    if (filteredAjuan.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox_outlined, size: 80, color: Colors.grey[400]),
            const SizedBox(height: 16),
            Text('Belum ada ajuan', style: TextStyle(fontSize: 16, color: Colors.grey[600], fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Text(
              filterStatus == 'semua'
                  ? 'Belum ada mahasiswa yang mengajukan'
                  : 'Tidak ada ajuan dengan status $filterStatus',
              style: TextStyle(fontSize: 14, color: Colors.grey[500]),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadAjuan,
      color: primaryColor,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: filteredAjuan.length,
        itemBuilder: (context, index) => _buildAjuanCard(filteredAjuan[index]),
      ),
    );
  }

  Widget _buildAjuanCard(Map<String, dynamic> ajuan) {
    final int intId = int.parse(ajuan['id'].toString());
    final status = (ajuan['status'] ?? '').toString().toLowerCase();

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 8, offset: const Offset(0, 5))],
      ),
      child: Column(
        children: [
          GestureDetector(
            onTap: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => FormAjuanDospemPage(ajuanId: ajuan['id'])),
              );

              if (result == true) _loadAjuan();
            },
            child: Row(
              children: [
                CircleAvatar(radius: 26, backgroundColor: primaryColor.withOpacity(0.12), child: const Icon(Icons.person, color: primaryColor, size: 30)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(ajuan['nama_mahasiswa'] ?? 'Tidak diketahui', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, fontFamily: 'Poppins')),
                      const SizedBox(height: 4),
                      Text(ajuan['nim'] ?? '-', style: const TextStyle(fontSize: 13, color: Color(0xFF616161), fontWeight: FontWeight.w600)),
                      const SizedBox(height: 2),
                      Text(ajuan['program_studi'] ?? '-', style: const TextStyle(fontSize: 13, color: Color(0xFF616161), fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
                if (ajuan['status'] != null) ...[
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(color: _getStatusColor(ajuan['status']), borderRadius: BorderRadius.circular(12)),
                    child: Text(_getStatusLabel(ajuan['status']), style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                  ),
                ],
                const SizedBox(width: 8),
                const Icon(Icons.arrow_forward_ios, color: Colors.black87, size: 18),
              ],
            ),
          ),

          // Action buttons when pending
          if (status == 'menunggu') ...[
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _processingIds.contains(intId)
                      ? Container(
                          height: 44,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(color: Colors.green, borderRadius: BorderRadius.circular(8)),
                          child: const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
                        )
                      : ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                          onPressed: () => _confirmTerima(ajuan['id']),
                          child: const Text('Terima', style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _processingIds.contains(intId)
                      ? Container(
                          height: 44,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(8)),
                          child: const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
                        )
                      : ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                          onPressed: () => _showTolakDialog(ajuan['id']),
                          child: const Text('Tolak', style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  void _confirmTerima(dynamic id) {
    Get.defaultDialog(
      title: 'Konfirmasi',
      middleText: 'Terima ajuan ini?',
      textConfirm: 'Ya',
      textCancel: 'Batal',
      onConfirm: () {
        Get.back();
        _terimaAjuan(id);
      },
    );
  }

  Future<void> _terimaAjuan(dynamic id) async {
    final int intId = int.parse(id.toString());
    if (_processingIds.contains(intId)) return;
    setState(() => _processingIds.add(intId));

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token');
      if (token == null) throw 'Token tidak ditemukan';

      final result = await AjukanPembimbingService.terimaAjuan(id: intId, token: token);

      if (result['success'] == true) {
        Get.snackbar('Sukses', result['message'] ?? 'Ajuan diterima', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.green, colorText: Colors.white);

        // Refresh ajuan list
        await _loadAjuan();

        // Try to refresh daftar mahasiswa but don't let failures block the flow or spam logs.
        try {
          // small delay to give backend time to finalize transaction
          await Future.delayed(const Duration(milliseconds: 700));
          final mahasiswaController = Get.isRegistered<DaftarMahasiswaController>() ? Get.find<DaftarMahasiswaController>() : Get.put(DaftarMahasiswaController());
          // call with a timeout so that a failing endpoint won't hang UI
          await mahasiswaController.loadMahasiswa().timeout(const Duration(seconds: 5));
        } catch (e) {
          // non-fatal: show info but don't treat as error
          Get.snackbar('Info', 'Daftar mahasiswa belum bisa diperbarui: $e', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.orange, colorText: Colors.white);
        }
      } else {
        Get.snackbar('Gagal', result['message'] ?? 'Gagal menerima ajuan', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red, colorText: Colors.white);
      }
    } catch (e) {
      Get.snackbar('Error', 'Terjadi kesalahan: $e', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red, colorText: Colors.white);
    } finally {
      setState(() => _processingIds.remove(intId));
    }
  }

  void _showTolakDialog(dynamic id) {
    final controller = TextEditingController();

    Get.defaultDialog(
      title: 'Tolak Ajuan',
      content: Column(
        children: [
          const Text('Berikan catatan penolakan (opsional):'),
          const SizedBox(height: 8),
          TextField(controller: controller, maxLines: 3, decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Catatan...')),
        ],
      ),
      textCancel: 'Batal',
      textConfirm: 'Tolak',
      onConfirm: () async {
        final catatan = controller.text.trim();
        Get.back();
        await _tolakAjuan(id, catatan);
      },
    );
  }

  Future<void> _tolakAjuan(dynamic id, String catatan) async {
    final int intId = int.parse(id.toString());
    if (_processingIds.contains(intId)) return;
    setState(() => _processingIds.add(intId));

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token');
      if (token == null) throw 'Token tidak ditemukan';

      final result = await AjukanPembimbingService.tolakAjuan(id: intId, catatanDosen: catatan, token: token);

      if (result['success'] == true) {
        Get.snackbar('Sukses', result['message'] ?? 'Ajuan ditolak', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.green, colorText: Colors.white);
        await _loadAjuan();
      } else {
        Get.snackbar('Gagal', result['message'] ?? 'Gagal menolak ajuan', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red, colorText: Colors.white);
      }
    } catch (e) {
      Get.snackbar('Error', 'Terjadi kesalahan: $e', snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red, colorText: Colors.white);
    } finally {
      setState(() => _processingIds.remove(intId));
    }
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'menunggu':
        return Colors.orange;
      case 'diterima':
        return Colors.green;
      case 'ditolak':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  String _getStatusLabel(String status) {
    switch (status.toLowerCase()) {
      case 'menunggu':
        return 'Menunggu';
      case 'diterima':
        return 'Diterima';
      case 'ditolak':
        return 'Ditolak';
      default:
        return status;
    }
  }
}

/// ======================== BOTTOM NAV DOSEN ========================
class _BottomNavDosen extends StatelessWidget {
  final PageTypeDosen currentPage;
  const _BottomNavDosen({required this.currentPage});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<MenuDosenController>();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: const BoxDecoration(
        gradient: LinearGradient(colors: [primaryColor, dangerColor], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.only(topLeft: Radius.circular(25), topRight: Radius.circular(25)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _BottomNavItem(icon: Icons.home, label: "Beranda", isActive: currentPage == PageTypeDosen.home, onTap: () => Get.offAllNamed(Routes.HOME_DOSEN)),
          _BottomNavItem(icon: Icons.schedule_outlined, label: "Jadwal", isActive: currentPage == PageTypeDosen.jadwal, onTap: () => Get.offAllNamed(Routes.JADWAL_DOSEN)),
          _BottomNavItem(icon: Icons.school_outlined, label: "Bimbingan", isActive: currentPage == PageTypeDosen.bimbingan, onTap: () => Get.offAllNamed(Routes.BIMBINGAN_DOSEN)),
          _BottomNavItem(icon: Icons.description_outlined, label: "Dokumen", isActive: currentPage == PageTypeDosen.dokumen, onTap: () => Get.offAllNamed(Routes.DOKUMEN_DOSEN)),
          _BottomNavItem(icon: Icons.person_outline, label: "Profile", isActive: currentPage == PageTypeDosen.profile, onTap: () => Get.offAllNamed(Routes.PROFILE_DOSEN)),
        ],
      ),
    );
  }
}

class _BottomNavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isActive;
  const _BottomNavItem({required this.icon, required this.label, required this.onTap, this.isActive = false});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: isActive ? Colors.yellow : Colors.white, size: 26),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(color: isActive ? Colors.yellow : Colors.white, fontSize: 12, fontWeight: isActive ? FontWeight.bold : FontWeight.w500)),
        ],
      ),
    );
  }
}
