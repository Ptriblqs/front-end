import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:inta301/controllers/auth_controller.dart';
import 'package:inta301/controllers/monitoring_dospem_controller.dart';

// Global
import 'package:inta301/shared/shared.dart';
import 'package:inta301/routes/app_pages.dart';

// Menu controller
import 'package:inta301/controllers/menu_controller.dart' as myCtrl;

class HomePage extends StatefulWidget {
  final bool hasDosen;

  const HomePage({super.key, required this.hasDosen});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final menuC = Get.find<myCtrl.MenuController>();
  final monitoringC = Get.put(MonitoringDospemController());

  @override
  void initState() {
    super.initState();
    monitoringC.fetchAjuan();
  }

  /// ================= STATUS PENGUNCIAN MENU =================
  bool get isMenunggu {
    final data = monitoringC.ajuanAktif.value;
    if (data == null) return false;
    return data['status'] == 'menunggu';
  }

  @override
  Widget build(BuildContext context) {
    const mainBlue = Color(0xFF88BDF2);

    // ⚠️ JANGAN pakai Obx / setState di sini
    menuC.setPage(myCtrl.PageType.home);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _buildAppBar(),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(defaultMargin),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildGreeting(),
              const SizedBox(height: 25),

              /// ================= PENGUMUMAN =================
              const Text(
                "Pengumuman",
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                height: 160,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: const [
                    _InfoCard(title: "Template Laporan", mainBlue: mainBlue),
                    SizedBox(width: 12),
                    _InfoCard(title: "Jadwal Sidang", mainBlue: mainBlue),
                    SizedBox(width: 12),
                    _InfoCard(title: "Panduan Sidang", mainBlue: mainBlue),
                  ],
                ),
              ),

              const SizedBox(height: 25),

              /// ================= MONITORING AJUAN DOSPEM =================
              _buildMonitoringCard(),
            ],
          ),
        ),
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  /// ================= APP BAR =================
  AppBar _buildAppBar() {
    return AppBar(
      automaticallyImplyLeading: false,
      elevation: 6,
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [primaryColor, dangerColor],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
      ),
      title: const Text(
        'Beranda',
        style: TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
      centerTitle: true,
      actions: [
        IconButton(
          icon: const Icon(Icons.notifications_none, color: Colors.white),
          onPressed: () => Get.toNamed(Routes.NOTIFIKASI),
        ),
      ],
    );
  }

  /// ================= GREETING =================
  Widget _buildGreeting() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.45),
            blurRadius: 12,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Obx(() {
        final authC = Get.find<AuthController>();
        final nama = authC.user['nama_lengkap'] ?? 'Mahasiswa';

        return Text(
          nama.toString().isNotEmpty
              ? "Halo, ${nama.toString()} 👋"
              : "Halo 👋",
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w700,
          ),
        );
      }),
    );
  }

  /// ================= MONITORING AJUAN DOSPEM =================
  Widget _buildMonitoringCard() {
    return Obx(() {
      if (monitoringC.isLoading.value) {
        return const Center(child: CircularProgressIndicator());
      }

      final data = monitoringC.ajuanAktif.value;
      if (data == null) {
        return _buildEmptyState();
      }

      final status = data['status'] ?? 'menunggu';

      Color color;
      String text;

      switch (status) {
        case 'diterima':
          color = Colors.green;
          text = 'Disetujui';
          break;
        case 'ditolak':
          color = Colors.red;
          text = 'Ditolak';
          break;
        default:
          color = Colors.orange;
          text = 'Menunggu Konfirmasi';
      }

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.45),
              blurRadius: 12,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Monitoring Pengajuan Dosen Pembimbing",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: dangerColor,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 10),
            Text("Dosen: ${data['dosen']?['user']?['nama_lengkap'] ?? '-'}"),
            Text("Prodi: ${data['program_studi']?['nama_prodi'] ?? '-'}"),
            const SizedBox(height: 8),

            Text(
              "Status: $text",
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: color,
              ),
            ),

            /// ================= TINDAKAN LANJUT =================
            if (status == 'diterima') ...[
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Get.offAllNamed(Routes.JADWAL);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: const Text(
                    "Ajukan Jadwal",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      );
    });
  }

  Widget _buildEmptyState() {
    return const Padding(
      padding: EdgeInsets.only(top: 20),
      child: Center(
        child: Text(
          "Belum ada pengajuan dosen pembimbing",
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Color(0xFF616161),
          ),
        ),
      ),
    );
  }

  /// ================= BOTTOM NAV (TERKUNCI SAAT MENUNGGU) =================
  Widget _buildBottomNav() {
    return Obx(() {
      final bool lock = isMenunggu;

      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [primaryColor, dangerColor],
          ),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(25),
            topRight: Radius.circular(25),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _BottomNavItem(
              icon: Icons.home,
              label: "Beranda",
              isActive: true,
              onTap: () => Get.offAllNamed(Routes.home),
            ),
            _BottomNavItem(
              icon: Icons.calendar_month,
              label: "Jadwal",
              isDisabled: lock,
              onTap: lock ? null : () => Get.offAllNamed(Routes.JADWAL),
            ),
            _BottomNavItem(
              icon: Icons.bar_chart_outlined,
              label: "Kanban",
              isDisabled: lock,
              onTap: lock ? null : () => Get.offAllNamed(Routes.KANBAN),
            ),
            _BottomNavItem(
              icon: Icons.description_outlined,
              label: "Dokumen",
              isDisabled: lock,
              onTap: lock ? null : () => Get.offAllNamed(Routes.DOKUMEN),
            ),
            _BottomNavItem(
              icon: Icons.person_outline,
              label: "Profile",
              onTap: () => Get.offAllNamed(Routes.PROFILE),
            ),
          ],
        ),
      );
    });
  }
}

/// ================= INFO CARD =================
class _InfoCard extends StatelessWidget {
  final String title;
  final Color mainBlue;

  const _InfoCard({required this.title, required this.mainBlue});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 160,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.45),
            blurRadius: 15,
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: dangerColor,
              fontWeight: FontWeight.w700,
              fontSize: 15,
            ),
          ),
          ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              backgroundColor: mainBlue,
              minimumSize: const Size(100, 40),
            ),
            child: const Text(
              "Lihat",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// ================= BOTTOM NAV ITEM =================
class _BottomNavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final bool isActive;
  final bool isDisabled;

  const _BottomNavItem({
    required this.icon,
    required this.label,
    this.onTap,
    this.isActive = false,
    this.isDisabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final Color color = isDisabled
        ? Colors.grey.shade400
        : isActive
            ? Colors.yellow
            : Colors.white;

    return GestureDetector(
      onTap: isDisabled ? null : onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
