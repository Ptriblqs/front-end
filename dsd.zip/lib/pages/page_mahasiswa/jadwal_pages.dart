import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';

import 'package:inta301/shared/shared.dart';
import 'package:inta301/routes/app_pages.dart';
import 'package:inta301/services/bimbingan_service.dart';

class JadwalPage extends StatefulWidget {
  const JadwalPage({super.key});

  @override
  State<JadwalPage> createState() => _JadwalPageState();
}

class _JadwalPageState extends State<JadwalPage> {
  final BimbinganService _bimbinganService = BimbinganService();
  DateTime today = DateTime.now();

  bool isLoading = true;
  bool hasDosen = false;
  List<dynamic> jadwalList = [];
  Set<DateTime> jadwalDiterimaDates = {};

  final TextEditingController _judulController = TextEditingController();
  final TextEditingController _tanggalController = TextEditingController();
  final TextEditingController _waktuController = TextEditingController();
  final TextEditingController _lokasiController = TextEditingController();
  final TextEditingController _catatanController = TextEditingController();

  String _selectedJenisBimbingan = 'offline';

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _judulController.dispose();
    _tanggalController.dispose();
    _waktuController.dispose();
    _lokasiController.dispose();
    _catatanController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => isLoading = true);

    try {
      final response = await _bimbinganService.getJadwalMahasiswa();

      print('📥 Response from API: $response'); // Debug log

      if (response['success'] == true) {
        setState(() {
          // ✅ Handle null dengan default value false
          hasDosen = response['has_dosen'] ?? false;
          jadwalList = response['data'] ?? [];
        });

        print('✅ hasDosen: $hasDosen'); // Debug log
        print('✅ jadwalList: ${jadwalList.length} items'); // Debug log

        if (hasDosen) {
          await _loadKalender();
        }
      } else {
        Get.snackbar('Error', response['message'] ?? 'Gagal memuat data');
      }
    } catch (e) {
      print('❌ Error loading data: $e'); // Debug log
      Get.snackbar('Error', 'Gagal memuat data: $e');
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _loadKalender() async {
    try {
      final response = await _bimbinganService.getKalenderMahasiswa();

      if (response['success'] == true) {
        setState(() {
          jadwalDiterimaDates = (response['data'] as List)
              .map((item) => DateTime.parse(item['date']))
              .toSet();
        });
      }
    } catch (e) {
      print('❌ Error loading kalender: $e');
    }
  }

  void _onDaySelected(DateTime day, DateTime focusedDay) {
    setState(() {
      today = day;
    });
  }

  void _showTambahJadwalModal(BuildContext context) {
    final BuildContext pageContext = context;
    _judulController.clear();
    _tanggalController.clear();
    _waktuController.clear();
    _lokasiController.clear();
    _catatanController.clear();
    _selectedJenisBimbingan = 'offline';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (modalContext) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setModalState) {
            return DraggableScrollableSheet(
              expand: false,
              initialChildSize: 0.75,
              minChildSize: 0.4,
              maxChildSize: 0.95,
              builder: (context, scrollController) {
                return Container(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(25),
                    ),
                  ),
                  child: SingleChildScrollView(
                    controller: scrollController,
                    padding: EdgeInsets.only(
                      left: 20,
                      right: 20,
                      top: 20,
                      bottom: MediaQuery.of(context).viewInsets.bottom + 20,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Center(
                          child: Container(
                            width: 60,
                            height: 5,
                            decoration: BoxDecoration(
                              color: Colors.grey[300],
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        const Center(
                          child: Text(
                            "Ajukan Jadwal Bimbingan",
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                              fontFamily: 'Poppins',
                            ),
                          ),
                        ),
                        const SizedBox(height: 25),
                        _buildLabel("Judul Bimbingan"),
                        _buildField(_judulController, "Contoh: Diskusi BAB 1"),
                        const SizedBox(height: 15),
                        _buildLabel("Tanggal"),
                        _buildDatePicker(modalContext, setModalState),
                        const SizedBox(height: 15),
                        _buildLabel("Waktu (contoh: 10:30)"),
                        _buildField(_waktuController, "Contoh: 10:30"),
                        const SizedBox(height: 15),
                        _buildLabel("Jenis Bimbingan"),
                        Row(
                          children: [
                            Expanded(
                              child: RadioListTile<String>(
                                title: const Text(
                                  'Offline',
                                  style: TextStyle(fontFamily: 'Poppins'),
                                ),
                                value: 'offline',
                                groupValue: _selectedJenisBimbingan,
                                onChanged: (value) {
                                  setModalState(() {
                                    _selectedJenisBimbingan = value!;
                                  });
                                },
                                activeColor: primaryColor,
                                contentPadding: EdgeInsets.zero,
                              ),
                            ),
                            Expanded(
                              child: RadioListTile<String>(
                                title: const Text(
                                  'Online',
                                  style: TextStyle(fontFamily: 'Poppins'),
                                ),
                                value: 'online',
                                groupValue: _selectedJenisBimbingan,
                                onChanged: (value) {
                                  setModalState(() {
                                    _selectedJenisBimbingan = value!;
                                  });
                                },
                                activeColor: primaryColor,
                                contentPadding: EdgeInsets.zero,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 15),
                        _buildLabel("Lokasi"),
                        _buildField(
                          _lokasiController,
                          _selectedJenisBimbingan == 'online'
                              ? "Link Zoom/Google Meet"
                              : "Contoh: Ruang B-203",
                        ),
                        const SizedBox(height: 15),
                        _buildLabel("Catatan (Opsional)"),
                        _buildField(
                          _catatanController,
                          "Catatan tambahan",
                          maxLines: 3,
                        ),
                        const SizedBox(height: 30),
                        SizedBox(
                          width: double.infinity,
                          height: 55,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: dangerColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                            ),
                            onPressed: () => _submitJadwal(pageContext),
                            child: const Text(
                              "Ajukan",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                                fontFamily: 'Poppins',
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  Future<void> _submitJadwal([BuildContext? rootContext]) async {
    // Validasi
    if (_judulController.text.trim().isEmpty) {
      final msg = 'Judul bimbingan harus diisi';
      if (rootContext != null) {
        ScaffoldMessenger.of(rootContext).showSnackBar(
          SnackBar(
            content: Text(msg),
            backgroundColor: Colors.red[100],
            behavior: SnackBarBehavior.floating,
          ),
        );
      } else {
        Get.snackbar('Error', msg);
      }
      return;
    }
    if (_tanggalController.text.isEmpty) {
      final msg = 'Tanggal harus dipilih';
      if (rootContext != null) {
        ScaffoldMessenger.of(rootContext).showSnackBar(
          SnackBar(
            content: Text(msg),
            backgroundColor: Colors.red[100],
            behavior: SnackBarBehavior.floating,
          ),
        );
      } else {
        Get.snackbar('Error', msg);
      }
      return;
    }
    if (_waktuController.text.trim().isEmpty) {
      final msg = 'Waktu harus diisi';
      if (rootContext != null) {
        ScaffoldMessenger.of(rootContext).showSnackBar(
          SnackBar(
            content: Text(msg),
            backgroundColor: Colors.red[100],
            behavior: SnackBarBehavior.floating,
          ),
        );
      } else {
        Get.snackbar('Error', msg);
      }
      return;
    }
    if (_lokasiController.text.trim().isEmpty) {
      final msg = 'Lokasi harus diisi';
      if (rootContext != null) {
        ScaffoldMessenger.of(rootContext).showSnackBar(
          SnackBar(
            content: Text(msg),
            backgroundColor: Colors.red[100],
            behavior: SnackBarBehavior.floating,
          ),
        );
      } else {
        Get.snackbar('Error', msg);
      }
      return;
    }

    try {
      // Parse tanggal
      final DateFormat inputFormat = DateFormat('EEEE, dd MMMM yyyy', 'id_ID');
      final DateTime parsedDate = inputFormat.parse(_tanggalController.text);
      final String formattedDate = DateFormat('yyyy-MM-dd').format(parsedDate);

      // Validasi waktu
      final timeRegex = RegExp(r'^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$');
      if (!timeRegex.hasMatch(_waktuController.text.trim())) {
        final msg = 'Format waktu harus HH:mm (contoh: 10:30)';
        if (rootContext != null) {
          ScaffoldMessenger.of(rootContext).showSnackBar(
            SnackBar(
              content: Text(msg),
              backgroundColor: Colors.red[100],
              behavior: SnackBarBehavior.floating,
            ),
          );
        } else {
          Get.snackbar('Error', msg);
        }
        return;
      }

      // Debug log
      print('📤 Submitting jadwal...');
      print('Judul: ${_judulController.text.trim()}');
      print('Tanggal: $formattedDate');
      print('Waktu: ${_waktuController.text.trim()}');
      print('Lokasi: ${_lokasiController.text.trim()}');
      print('Jenis: $_selectedJenisBimbingan');
      print('Catatan: ${_catatanController.text.trim()}');

      final response = await _bimbinganService.ajukanBimbinganMahasiswa(
        judul: _judulController.text.trim(),
        tanggal: formattedDate,
        waktu: _waktuController.text.trim(),
        lokasi: _lokasiController.text.trim(),
        jenisBimbingan: _selectedJenisBimbingan,
        catatan: _catatanController.text.trim().isEmpty
            ? null
            : _catatanController.text.trim(),
      );

      print('📥 Response: $response'); // Debug log

      if (response['success'] == true) {
        Get.back(); // Tutup modal
        final msg = response['message'] ?? 'Jadwal bimbingan berhasil diajukan';
        if (rootContext != null) {
          ScaffoldMessenger.of(rootContext).showSnackBar(
            SnackBar(
              content: Text(msg),
              backgroundColor: Colors.white,
              behavior: SnackBarBehavior.floating,
              duration: const Duration(seconds: 3),
            ),
          );
        } else {
          Get.snackbar(
            "Berhasil",
            msg,
            backgroundColor: Colors.white,
            colorText: Colors.black,
            snackPosition: SnackPosition.TOP,
            icon: const Icon(Icons.check_circle, color: Colors.green),
            duration: const Duration(seconds: 3),
          );
        }
        await _loadData(); // Reload data
      } else {
        final msg = response['message'] ?? 'Gagal mengajukan jadwal';
        if (rootContext != null) {
          ScaffoldMessenger.of(rootContext).showSnackBar(
            SnackBar(
              content: Text(msg),
              backgroundColor: Colors.red[100],
              behavior: SnackBarBehavior.floating,
            ),
          );
        } else {
          Get.snackbar(
            'Error',
            msg,
            backgroundColor: Colors.red[100],
            colorText: Colors.red[900],
            snackPosition: SnackPosition.TOP,
          );
        }
      }
    } catch (e) {
      print('❌ Error: $e'); // Debug log
      final msg = 'Gagal mengajukan jadwal: $e';
      if (rootContext != null) {
        ScaffoldMessenger.of(rootContext).showSnackBar(
          SnackBar(
            content: Text(msg),
            backgroundColor: Colors.red[100],
            behavior: SnackBarBehavior.floating,
          ),
        );
      } else {
        Get.snackbar(
          'Error',
          msg,
          backgroundColor: Colors.red[100],
          colorText: Colors.red[900],
          snackPosition: SnackPosition.TOP,
        );
      }
    }
  }

  Widget _buildDatePicker(BuildContext modalContext, StateSetter setModalState) {
    return GestureDetector(
      onTap: () async {
        FocusScope.of(modalContext).unfocus();
        DateTime? pickedDate = await showDatePicker(
          context: modalContext,
          initialDate: DateTime.now(),
          firstDate: DateTime.now(),
          lastDate: DateTime(2030),
          locale: const Locale('id', 'ID'),
          builder: (context, child) {
            return Theme(
              data: Theme.of(context).copyWith(
                colorScheme: ColorScheme.light(
                  primary: primaryColor,
                  onPrimary: Colors.white,
                  onSurface: Colors.black,
                ),
              ),
              child: child!,
            );
          },
        );
        if (pickedDate != null) {
          // ✅ Gunakan setModalState untuk update UI di modal
          setModalState(() {
            _tanggalController.text = DateFormat(
              'EEEE, dd MMMM yyyy',
              'id_ID',
            ).format(pickedDate);
          });
        }
      },
      child: AbsorbPointer(
        child: TextField(
          controller: _tanggalController,
          style: const TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.w500,
            fontFamily: 'Poppins',
          ),
          decoration: _fieldDecoration().copyWith(
            suffixIcon: Icon(
              Icons.calendar_today_outlined,
              color: primaryColor,
            ),
            hintText: "Pilih tanggal bimbingan",
          ),
        ),
      ),
    );
  }

  InputDecoration _fieldDecoration() {
    return InputDecoration(
      filled: true,
      fillColor: primaryColor.withOpacity(0.2),
      contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 15),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: primaryColor.withOpacity(0.3), width: 1),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: primaryColor.withOpacity(0.3), width: 1),
      ),
      focusedBorder: const OutlineInputBorder(
        borderRadius: BorderRadius.all(Radius.circular(16)),
        borderSide: BorderSide(color: primaryColor, width: 1.5),
      ),
    );
  }

  Widget _buildLabel(String text) {
    return Text(
      text,
      style: const TextStyle(
        fontWeight: FontWeight.w600,
        fontSize: 14,
        fontFamily: 'Poppins',
      ),
    );
  }

  Widget _buildField(
    TextEditingController controller,
    String hint, {
    int maxLines = 1,
  }) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      style: const TextStyle(
        color: Colors.black,
        fontWeight: FontWeight.w500,
        fontFamily: 'Poppins',
      ),
      decoration: _fieldDecoration().copyWith(hintText: hint),
    );
  }

  Widget _buildJadwalCard(Map<String, dynamic> item) {
    final status = item["status"] ?? "Menunggu";
    Color statusColor;

    switch (status) {
      case "Diterima":
      case "Disetujui":
        statusColor = Colors.green;
        break;
      case "Ditolak":
        statusColor = Colors.red;
        break;
      case "Menunggu":
        statusColor = Colors.blueAccent;
        break;
      case "Ajuan Dosen":
        statusColor = Colors.orange;
        break;
      default:
        statusColor = Colors.grey;
    }

    final bool isAjuanDosen = status == "Ajuan Dosen";

    return GestureDetector(
      onTap: isAjuanDosen
          ? () {
              Get.toNamed(
                Routes.FORM_JADWAL,
                arguments: {
                  "jadwalId": item["id"] ?? item["jadwalId"], // ✅ Fallback
                  "mode": "mahasiswa_respon",
                },
              )?.then((_) => _loadData());
            }
          : null,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: isAjuanDosen
              ? Border.all(color: Colors.orange, width: 2)
              : null,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.25),
              blurRadius: 8,
              spreadRadius: 2,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    item["judul"] ?? "-",
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      fontFamily: 'Poppins',
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    vertical: 4,
                    horizontal: 8,
                  ),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    status,
                    style: TextStyle(
                      color: statusColor,
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                      fontFamily: 'Poppins',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              "${item["tanggal"] ?? "-"} | ${item["waktu"] ?? "-"}",
              style: const TextStyle(
                fontSize: 13,
                color: Colors.grey,
                fontFamily: 'Poppins',
              ),
            ),
            const SizedBox(height: 4),
            Text(
              item["lokasi"] ?? "-",
              style: const TextStyle(
                fontSize: 13,
                color: Colors.black87,
                fontFamily: 'Poppins',
              ),
            ),
          ],
        ),
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      automaticallyImplyLeading: false,
      title: const Text(
        "Jadwal Bimbingan",
        style: TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.white,
          fontFamily: 'Poppins',
        ),
      ),
      centerTitle: true,
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [primaryColor, dangerColor],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        appBar: _buildAppBar(),
        body: const Center(
          child: CircularProgressIndicator(color: primaryColor),
        ),
        bottomNavigationBar: const _BottomNavBar(),
      );
    }

    // if (!hasDosen) {
    //   return Scaffold(
    //     appBar: _buildAppBar(),
    //     body: const Padding(
    //       padding: EdgeInsets.only(top: 100),
    //       child: Center(
    //         child: Column(
    //           mainAxisSize: MainAxisSize.min,
    //           children: [
    //             Icon(Icons.person_off, size: 80, color: Colors.grey),
    //             SizedBox(height: 20),
    //             Text(
    //               "Belum memiliki dosen pembimbing.",
    //               style: TextStyle(
    //                 fontSize: 16,
    //                 fontWeight: FontWeight.w600,
    //                 color: Color(0xFF616161),
    //                 fontFamily: 'Poppins',
    //               ),
    //             ),
    //             SizedBox(height: 10),
    //             Text(
    //               "Silakan hubungi admin untuk penugasan dosen.",
    //               textAlign: TextAlign.center,
    //               style: TextStyle(
    //                 fontSize: 13,
    //                 color: Colors.grey,
    //                 fontFamily: 'Poppins',
    //               ),
    //             ),
    //           ],
    //         ),
    //       ),
    //     ),
    //     bottomNavigationBar: const _BottomNavBar(),
    //   );
    // }

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: _buildAppBar(),
      body: RefreshIndicator(
        onRefresh: _loadData,
        color: primaryColor,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: TableCalendar(
                  locale: 'id_ID',
                  rowHeight: 45,
                  focusedDay: today,
                  firstDay: DateTime.utc(2020, 1, 1),
                  lastDay: DateTime.utc(2030, 12, 31),
                  selectedDayPredicate: (day) => isSameDay(day, today),
                  onDaySelected: _onDaySelected,
                  calendarBuilders: CalendarBuilders(
                    markerBuilder: (context, date, events) {
                      if (jadwalDiterimaDates.any((d) => isSameDay(d, date))) {
                        return Positioned(
                          bottom: 1,
                          child: Container(
                            width: 7,
                            height: 7,
                            decoration: const BoxDecoration(
                              color: dangerColor,
                              shape: BoxShape.circle,
                            ),
                          ),
                        );
                      }
                      return null;
                    },
                  ),
                  headerStyle: const HeaderStyle(
                    formatButtonVisible: false,
                    titleCentered: true,
                    titleTextStyle: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Poppins',
                      fontSize: 16,
                    ),
                  ),
                  calendarStyle: const CalendarStyle(
                    todayDecoration: BoxDecoration(
                      color: primaryColor,
                      shape: BoxShape.circle,
                    ),
                    selectedDecoration: BoxDecoration(
                      color: primaryColor,
                      shape: BoxShape.circle,
                    ),
                    todayTextStyle: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                    selectedTextStyle: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: Builder(builder: (context) {
                  if (jadwalList.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.calendar_today_outlined,
                            size: 60,
                            color: Colors.grey[400],
                          ),
                          const SizedBox(height: 15),
                          const Text(
                            'Belum ada jadwal bimbingan',
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontSize: 15,
                              color: Colors.grey,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'Tekan tombol + untuk mengajukan',
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontSize: 13,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    );
                  }

                  final acceptedList = jadwalList.where((item) {
                    final s = (item['status'] ?? '').toString().toLowerCase();
                    return s.contains('diterima') || s.contains('disetujui') || s.contains('dijadwalkan');
                  }).toList();

                  final pendingList = jadwalList.where((item) {
                    final s = (item['status'] ?? '').toString().toLowerCase();
                    return !(s.contains('diterima') || s.contains('disetujui') || s.contains('dijadwalkan'));
                  }).toList();

                  return ListView(
                    padding: const EdgeInsets.only(bottom: 12),
                    children: [
                      if (acceptedList.isNotEmpty) ...[
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                          child: Text('Jadwal Disetujui', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        ),
                        ...acceptedList.map((e) => _buildJadwalCard(e)).toList(),
                        const SizedBox(height: 12),
                      ],

                      if (pendingList.isNotEmpty) ...[
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                          child: Text('Sedang Diajukan', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        ),
                        ...pendingList.map((e) => _buildJadwalCard(e)).toList(),
                      ],
                    ],
                  );
                }),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: dangerColor,
        onPressed: () => _showTambahJadwalModal(context),
        child: const Icon(Icons.add, color: Colors.white, size: 30),
      ),
      bottomNavigationBar: const _BottomNavBar(),
    );
  }
}

// Bottom navigation bar
class _BottomNavBar extends StatefulWidget {
  const _BottomNavBar();

  @override
  State<_BottomNavBar> createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<_BottomNavBar> {
  String currentPage = Routes.JADWAL;

  void _onTap(String route) {
    if (route == currentPage) return;
    setState(() {
      currentPage = route;
    });
    Get.offAllNamed(route);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [primaryColor, dangerColor],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(25),
          topRight: Radius.circular(25),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _BottomNavItem(
            icon: Icons.home,
            label: "Beranda",
            isActive: currentPage == Routes.home,
            onTap: () => _onTap(Routes.home),
          ),
          _BottomNavItem(
            icon: Icons.calendar_month,
            label: "Jadwal",
            isActive: currentPage == Routes.JADWAL,
            onTap: () => _onTap(Routes.JADWAL),
          ),
          _BottomNavItem(
            icon: Icons.bar_chart_outlined,
            label: "Kanban",
            isActive: currentPage == Routes.KANBAN,
            onTap: () => _onTap(Routes.KANBAN),
          ),
          _BottomNavItem(
            icon: Icons.description_outlined,
            label: "Dokumen",
            isActive: currentPage == Routes.DOKUMEN,
            onTap: () => _onTap(Routes.DOKUMEN),
          ),
          _BottomNavItem(
            icon: Icons.person_outline,
            label: "Profile",
            isActive: currentPage == Routes.PROFILE,
            onTap: () => _onTap(Routes.PROFILE),
          ),
        ],
      ),
    );
  }
}

class _BottomNavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isActive;

  const _BottomNavItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.isActive = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: isActive ? Colors.yellow : Colors.white, size: 26),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: isActive ? Colors.yellow : Colors.white,
              fontSize: 12,
              fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
              fontFamily: 'Poppins',
            ),
          ),
        ],
      ),
    );
  }
}