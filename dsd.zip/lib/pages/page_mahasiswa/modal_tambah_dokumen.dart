import 'dart:typed_data';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';

import 'package:inta301/shared/shared.dart';
import '../../services/dokumen_service.dart';
import 'dokumen_controller.dart';

class TambahDokumenModal extends StatefulWidget {
  final BuildContext parentContext;

  const TambahDokumenModal({super.key, required this.parentContext});

  @override
  State<TambahDokumenModal> createState() => _TambahDokumenModalState();
}

class _TambahDokumenModalState extends State<TambahDokumenModal> {
  final judulController = TextEditingController();
  final babController = TextEditingController();
  final deskripsiController = TextEditingController();

  Uint8List? fileBytes;        // 🔥 WEB
  String? filePath;            // 🔥 MOBILE
  String? fileName;

  bool isUploading = false;

  // TODO: ganti dengan dosen_id dari sistem login
  final String dosenId = "1";

  // ================= PICK FILE =================
  Future<void> pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'doc', 'docx'],
      withData: kIsWeb, // 🔥 WAJIB UNTUK WEB
    );

    if (result != null) {
      final file = result.files.single;

      setState(() {
        fileName = file.name;

        if (kIsWeb) {
          fileBytes = file.bytes;
          filePath = null;
        } else {
          filePath = file.path;
          fileBytes = null;
        }
      });
    }
  }

  // ================= UPLOAD =================
  Future<void> uploadDokumen() async {
    if (judulController.text.isEmpty ||
        babController.text.isEmpty ||
        fileName == null) {
      Get.snackbar(
        "Error",
        "Judul, BAB, dan file wajib diisi",
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.TOP,
      );
      return;
    }

    setState(() => isUploading = true);

    try {
      // Build PlatformFile to match DokumenService API
      final pf = PlatformFile(
        name: fileName!,
        bytes: fileBytes,
        path: filePath,
        size: fileBytes?.lengthInBytes ?? (filePath != null ? 0 : 0),
      );

      final resp = await DokumenService.uploadDokumen(
        dosenId: dosenId,
        judul: judulController.text,
        bab: babController.text,
        deskripsi: deskripsiController.text,
        file: pf,
      );

      setState(() => isUploading = false);

      if (resp['success'] == true) {
        Get.find<DokumenController>().refresh();
        Get.back();

        ScaffoldMessenger.of(widget.parentContext).showSnackBar(
          const SnackBar(
            content: Text('Dokumen berhasil diupload'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      setState(() => isUploading = false);

      ScaffoldMessenger.of(widget.parentContext).showSnackBar(
        SnackBar(
          content: Text('Gagal upload dokumen: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // ================= UI =================
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _header(),
            _field(judulController, "Judul Dokumen *", "BAB I Pendahuluan"),
            _field(babController, "BAB *", "BAB I"),
            _field(deskripsiController, "Deskripsi", "Opsional", maxLines: 3),
            _filePicker(),
            _uploadButton(),
          ],
        ),
      ),
    );
  }

  Widget _header() => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            "Upload Dokumen Baru",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          IconButton(
            icon: const Icon(Icons.close),
            onPressed: () => Get.back(),
          ),
        ],
      );

  Widget _field(
    TextEditingController c,
    String label,
    String hint, {
    int maxLines = 1,
  }) =>
      Padding(
        padding: const EdgeInsets.only(top: 16),
        child: TextField(
          controller: c,
          maxLines: maxLines,
          decoration: InputDecoration(
            labelText: label,
            hintText: hint,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: primaryColor, width: 2),
            ),
          ),
        ),
      );

  Widget _filePicker() => Padding(
        padding: const EdgeInsets.only(top: 16),
        child: GestureDetector(
          onTap: pickFile,
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              border: Border.all(color: primaryColor),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const Icon(Icons.upload_file, color: primaryColor),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    fileName ?? "Pilih file (PDF/DOC/DOCX)",
                    style: TextStyle(
                      color: fileName != null ? Colors.black : Colors.grey,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );

  Widget _uploadButton() => Padding(
        padding: const EdgeInsets.only(top: 24),
        child: SizedBox(
          width: double.infinity,
          height: 50,
          child: ElevatedButton(
            onPressed: isUploading ? null : uploadDokumen,
            style: ElevatedButton.styleFrom(
              backgroundColor: primaryColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: isUploading
                ? const CircularProgressIndicator(color: Colors.white)
                : const Text(
                    "Upload Dokumen",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
          ),
        ),
      );

  @override
  void dispose() {
    judulController.dispose();
    babController.dispose();
    deskripsiController.dispose();
    super.dispose();
  }
}
