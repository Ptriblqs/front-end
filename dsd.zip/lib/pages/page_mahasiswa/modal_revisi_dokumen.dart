import 'package:flutter/material.dart';
import 'package:inta301/shared/shared.dart';
import 'package:inta301/pages/page_mahasiswa/dokumen_controller.dart';
import 'package:file_picker/file_picker.dart';
import 'package:inta301/services/dokumen_service.dart';
import 'package:get/get.dart';

void showRevisiModal(BuildContext context, DokumenModel dokumen) {
  showModalBottomSheet(
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    context: context,
    builder: (context) {
      return DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.65,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        builder: (context, scrollController) {
          return Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: SingleChildScrollView(
              controller: scrollController,
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom + 16,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Drag handle
                  Center(
                    child: Container(
                      width: 40,
                      height: 5,
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),

                  // Header
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        "Catatan Revisi Dosen",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close_rounded),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Catatan dosen
                  const Text(
                    "Catatan Dosen",
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: primaryColor.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: primaryColor.withOpacity(0.2)),
                    ),
                    child: Text(
                      dokumen.catatanDosen.isNotEmpty
                          ? dokumen.catatanDosen
                          : "Belum ada catatan dari dosen.",
                      style: const TextStyle(fontSize: 14),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // File revisi
                  const Text(
                    "File Revisi Dosen",
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
                    decoration: BoxDecoration(
                      color: primaryColor.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: primaryColor.withOpacity(0.2)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.picture_as_pdf, color: Colors.red),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            dokumen.fileRevisi.isNotEmpty
                                ? dokumen.fileRevisi
                                : "Belum ada file revisi",
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (dokumen.fileRevisi.isNotEmpty)
                          IconButton(
                            icon: const Icon(Icons.download_rounded, color: Colors.black87),
                            tooltip: "Unduh file revisi",
                            onPressed: () async {
                              try {
                                await Get.find<DokumenController>().downloadDokumen(dokumen);
                              } catch (e) {
                                Get.snackbar('Gagal', 'Gagal mengunduh file revisi: $e');
                              }
                            },
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 30),

                  // Upload revisi (MAHASISWA)
                  const Text(
                    "Upload Perbaikan",
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  StatefulBuilder(builder: (context, setState) {
                    PlatformFile? picked;
                    bool uploading = false;

                    Future<void> pickFile() async {
                      final res = await FilePicker.platform.pickFiles(
                        withData: true,
                        type: FileType.custom,
                        allowedExtensions: ['pdf', 'doc', 'docx'],
                      );
                      if (res != null && res.files.isNotEmpty) {
                        setState(() {
                          picked = res.files.first;
                        });
                      }
                    }

                    Future<void> upload() async {
                      if (picked == null || dokumen.id == null) return;
                      setState(() => uploading = true);
                      try {
                        await DokumenService.uploadRevisi(
                          dokumenId: dokumen.id!,
                          file: picked!,
                        );
                        // Refresh lists
                        await Get.find<DokumenController>().refresh();
                        Get.snackbar('Sukses', 'Revisi berhasil diunggah');
                        Navigator.pop(context);
                      } catch (e) {
                        Get.snackbar('Gagal', 'Gagal mengunggah revisi: $e');
                      } finally {
                        setState(() => uploading = false);
                      }
                    }

                    return Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade100,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.grey.shade300),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.attach_file, color: Colors.black54),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  picked?.name ?? 'Pilih file perbaikan (pdf/doc/docx)',
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              TextButton(
                                onPressed: () => pickFile(),
                                child: const Text('PILIH'),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          height: 48,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: primaryColor,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            onPressed: (picked != null && !uploading) ? upload : null,
                            child: uploading
                                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                : const Text('UPLOAD PERBAIKAN'),
                          ),
                        ),
                        const SizedBox(height: 12),
                      ],
                    );
                  }),

                  // Tombol Tutup
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: dangerColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () => Navigator.pop(context),
                      child: const Text(
                        "TUTUP",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}
