import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MonitoringDospemController extends GetxController {
  var isLoading = false.obs;

  /// data ajuan aktif (nullable)
  final Rxn<Map<String, dynamic>> ajuanAktif =
      Rxn<Map<String, dynamic>>();

  /// base url API (samakan dengan backend kamu)
  final String baseUrl = 'http://127.0.0.1:8000/api';

  Future<void> fetchAjuan() async {
    try {
      isLoading.value = true;

      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token');

      if (token == null || token.isEmpty) {
        ajuanAktif.value = null;
        return;
      }

      final response = await GetConnect().get(
        '$baseUrl/ajuan-dospem',
        headers: {
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
        },
      );

      if (response.statusCode == 200 &&
          response.body != null &&
          response.body['data'] != null &&
          response.body['data'].isNotEmpty) {
        /// ambil ajuan terakhir
        ajuanAktif.value = response.body['data'][0];
      } else {
        ajuanAktif.value = null;
      }
    } catch (e) {
      ajuanAktif.value = null;
    } finally {
      isLoading.value = false;
    }
  }
}
