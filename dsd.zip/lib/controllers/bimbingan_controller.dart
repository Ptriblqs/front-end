import 'package:get/get.dart';
import 'package:dio/dio.dart';
import 'package:inta301/shared/shared.dart';

class BimbinganController extends GetxController {
  final Dio _dio = Dio(
    BaseOptions(
      baseUrl: baseUrl, // pastikan ini sudah benar
      headers: {
        'Accept': 'application/json',
      },
    ),
  );

  /// 🔹 Ajukan jadwal bimbingan (MAHASISWA)
  Future<Map<String, dynamic>> ajukanJadwal({
    required String judul,
    required String tanggal,
    required String waktu,
    required String lokasi,
    required String jenisBimbingan,
    String? catatan,
  }) async {
    try {
      final response = await _dio.post(
        '/bimbingan/ajukan',
        data: {
          'judul': judul,
          'tanggal': tanggal,
          'waktu': waktu,
          'lokasi': lokasi,
          'jenis_bimbingan': jenisBimbingan, // 🔥 WAJIB SAMA
          'catatan': catatan,
        },
        options: Options(
          headers: {
            'Authorization': 'Bearer ${storage.read('token')}',
          },
        ),
      );

      return response.data;
    } on DioException catch (e) {
      if (e.response != null) {
        return e.response!.data;
      }
      return {
        'success': false,
        'message': 'Terjadi kesalahan jaringan'
      };
    }
  }

  /// 🔹 Ambil jadwal mahasiswa
  Future<Map<String, dynamic>> getJadwalMahasiswa() async {
    try {
      final response = await _dio.get(
        '/bimbingan',
        options: Options(
          headers: {
            'Authorization': 'Bearer ${storage.read('token')}',
          },
        ),
      );
      return response.data;
    } catch (e) {
      return {
        'success': false,
        'message': 'Gagal mengambil jadwal'
      };
    }
  }
}
