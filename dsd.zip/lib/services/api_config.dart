import 'package:flutter/foundation.dart';

class ApiConfig {
  static String get baseUrl {
    // Untuk web (opsional)
    if (kIsWeb) {
      return "http://127.0.0.1:8000/api";
    }

    // Untuk Android/iOS di HP fisik, ganti dengan IP PC kamu
    return "http://10.151.80.153:8000/api";
  }
}
