import 'dart:html' as html;
import 'dart:typed_data';

Future<void> saveFileBytes(String fileName, Uint8List bytes, {String? mimeType}) async {
  final blob = (mimeType != null)
      ? html.Blob([bytes], mimeType)
      : html.Blob([bytes]);
  final url = html.Url.createObjectUrlFromBlob(blob);
  final anchor = html.document.createElement('a') as html.AnchorElement;
  anchor.href = url;
  anchor.download = fileName;
  html.document.body?.append(anchor);
  anchor.click();
  anchor.remove();
  html.Url.revokeObjectUrl(url);
}
