import 'dart:io';
import 'dart:typed_data';

Future<void> saveFileBytes(String savePath, Uint8List bytes) async {
  final file = File(savePath);
  await file.writeAsBytes(bytes);
}
