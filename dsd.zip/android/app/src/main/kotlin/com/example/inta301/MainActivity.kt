package com.example.inta301

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
